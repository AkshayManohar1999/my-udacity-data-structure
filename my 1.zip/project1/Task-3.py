import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
def bangalore_call(call):
    return call[0][0:5] == '(080)'


def extract_area_code(call):
    call_other_interloc = call[1]

    if call_other_interloc[:2] == '(0':  # Fix land case
        return call_other_interloc.split(sep=')')[0] + ')'

    if call_other_interloc[:3] == '140':  # Telemarketer case
        return call_other_interloc[:3]

    else:  # Mobile case
        return call_other_interloc[:4]


if __name__ == '__main__':
    bng_called_prefix = []
    # Part A
    for call in calls:
        if bangalore_call(call):
            bng_called_prefix.append(extract_area_code(call))

    bng_called_prefix_resum = list(set(bng_called_prefix))
    bng_called_prefix_resum.sort()

    print("\n The numbers called by people ")
    for related_prefix in bng_called_prefix_resum:
        print(related_prefix)

    # Part B
    bng_recurrent_call_num = 0
    for call_prefix in bng_called_prefix:
        if call_prefix == "(080)":
            bng_recurrent_call_num += 1

    print("\n {} percent of calls from fixed lines in Bangalore .".format(
       round(bng_recurrent_call_num/len(bng_called_prefix)*100, 2)))
