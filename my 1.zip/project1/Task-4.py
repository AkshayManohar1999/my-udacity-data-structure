
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
if __name__ == '__main__':
    call_senders = set([data[0] for data in calls])
    call_receivers = set([data[1] for data in calls])
    message_senders = set([data[0] for data in texts])
    message_receivers = set([data[1] for data in texts])

    call_senders_susp = []

    for call_sender in call_senders:
        if (call_sender not in call_receivers and call_sender not in message_senders and
                call_sender not in message_receivers):
            call_senders_susp.append(call_sender)

    call_senders_susp.sort()

    print("\n telemarketers numbers :")
    for call_senser_susp in call_senders_susp:
        print(call_senser_susp)
