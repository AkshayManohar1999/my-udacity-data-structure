Problem 1
I first started counting up from 1 multiplying each iteration by itself until the target was reached. I then realized it'd be more efficient to take an approach similar to a BST.

Time Complexity: O(log(n))

Similar to searching a BST

Space Complexity: O(1)

Memory use is independent to the input. Each loop run is independent.

Problem 2
The rotated array is able to be searched using a Binary Search Algorithm. My first method involved finding the pivot seperately but I later realized this was not necessary and the element could be found in one pass.

Time Complexity: O(log n)

Binary Search

Space Complexity: O(1)

No additional space is used

Problem 3
I quickly noticed a pattern that the output was always a sequential alternation of the max elements. After realizing this I decided to use a max heap to sort the numbers. Then I popped off each number and alternated which output I appended to.

Time Complexity: O(nlog n)

Heapifying the array takes O(nlog n), popping every element takes O(nlog n), and creating the output takes O(n) resulting in O(nlog n).

Space Complexity: O(n)

The max heap creates a new array of size n.

Problem 4
To solve this problem I kept a pointer to where the next 0 and 2 should be added. Following this method the 1's sorted themselves automatically. The array was sorted in one pass.

Time Complexity: O(n)

The array is iterated through once.

Space Complexity: O(1)

Sorting was done in place.


Problem 5
For this trie I decided to use a defaultDict to store the children which made for cleaner looking code.

Find Method
Time Complexity: O(n)

Each character needs to be iterated through

Space Complexity: O(1)

No memory is allocated

Insert Method
Time Complexity: O(n)

Each character needs to be iterated through

Space Complexity: O(n)

n characters need to be allocated

Suffixes Method
Time Complexity: O(n)

Each character needs to be iterated through

Space Complexity: O(1)

No memory is allocated



Problem 6
My implementation sets the initial min and max values as the first value in the array. It then iterates once through and adjusts them accordingly.

Time Complexity: O(n)

The array is iterated through once.

Space Complexity: O(1)

No additional memory is allocated.

Problem 7
My implementation is exactly the same as problem 5 with some slight differences. I had to string clean the path by removing outside occurences of / with strip and then split it.

Add Handler Method
Time Complexity: O(n) Each part of the path needs to be iterated through

Space Complexity: O(n) A new TrieNode is created for each part of the path

Lookup Method
Time Complexity: O(n)

Space Complexity: O(1)

No additional memory is allocated